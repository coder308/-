"""钉钉提醒: send_alert(reason) → 发消息到手机"""
import requests, json, config
from datetime import datetime


def send_alert(reason=""):
    """通过钉钉群机器人发送分心提醒（必须包含关键词"提醒"）"""
    if not config.DINGTALK_WEBHOOK:
        print("未配置钉钉 Webhook")
        return

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    msg = {
        "msgtype": "text",
        "text": {
            "content": f"⚠️ 分心检测提醒！\n原因: {reason}\n时间: {now}"
        }
    }

    try:
        r = requests.post(config.DINGTALK_WEBHOOK,
                          data=json.dumps(msg),
                          headers={"Content-Type": "application/json"},
                          timeout=5)
        if r.status_code == 200 and r.json().get("errcode") == 0:
            print("钉钉提醒发送成功")
        else:
            print(f"钉钉发送失败: {r.json().get('errmsg', r.status_code)}")
    except Exception as e:
        print(f"钉钉错误: {e}")
