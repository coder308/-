"""分心时: 弹提示图 + 播报警音 + 保存画面 + 钉钉提醒（tkinter版）"""
import cv2, os, subprocess
from datetime import datetime
from PIL import Image, ImageTk
import tkinter as tk
import config
from notifier import send_alert


class AlertManager:
    def __init__(self, ai_analyzer=None, parent=None):
        self.ai_analyzer = ai_analyzer
        self.parent = parent
        self.warning_window = None
        os.makedirs(config.SAVE_DIR, exist_ok=True)

    def show_warning(self, frame, reason=""):
        if self.is_showing():
            return

        # 保存画面
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(config.SAVE_DIR, f"distract_{ts}.jpg")
        cv2.imwrite(path, frame)
        print(f"Saved: {path}")

        self._play_sound()
        send_alert(reason)
        self._show_image(reason)

    def _show_image(self, reason):
        """弹窗显示提示图片"""
        if not os.path.exists(config.WARNING_IMAGE_PATH):
            print(f"图片未找到: {config.WARNING_IMAGE_PATH}")
            self._reset_after_close()
            return

        if self.warning_window:
            try:
                self.warning_window.destroy()
            except:
                pass

        self.warning_window = tk.Toplevel(self.parent)
        self.warning_window.title("⚠️ DISTRACTED")
        self.warning_window.configure(bg="black")
        self.warning_window.grab_set()  # 模态窗口
        self.warning_window.focus_set()

        # 窗口关闭时的回调
        self.warning_window.protocol("WM_DELETE_WINDOW", self._close_image)

        img = Image.open(config.WARNING_IMAGE_PATH)
        img.thumbnail((400, 400))
        imgtk = ImageTk.PhotoImage(img)
        lbl = tk.Label(self.warning_window, image=imgtk, bg="black")
        lbl.imgtk = imgtk
        lbl.pack(padx=10, pady=10)

        tk.Label(self.warning_window, text="Distracted: " + reason,
                 fg="red", bg="black", font=("fixed", 14)).pack()
        tk.Button(self.warning_window, text="OK",
                  command=self._close_image).pack(pady=5)

    def _close_image(self):
        """关掉弹窗，通知 AI 重新倒计时"""
        if self.warning_window:
            try:
                self.warning_window.grab_release()
                self.warning_window.destroy()
            except:
                pass
            self.warning_window = None
        if self.ai_analyzer:
            self.ai_analyzer.reset_cooldown()

    def _play_sound(self):
        """播放报警音"""
        if os.path.exists(config.WARNING_SOUND_PATH):
            subprocess.Popen(["aplay", config.WARNING_SOUND_PATH],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def is_showing(self):
        return self.warning_window is not None and self.warning_window.winfo_exists()

    def cleanup(self):
        self._close_image()
