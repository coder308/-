"""界面: 显示摄像头画面 + 状态文字 + 退出按钮"""
import tkinter as tk
from PIL import Image, ImageTk
import cv2


class MainWindow:
    def __init__(self, root, on_close_callback):
        self.root = root
        self.on_close = on_close_callback
        self.root.title("Distraction Detection")
        self.root.configure(bg="black")
        self.root.geometry("800x600")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.label_video = tk.Label(root, bg="black")
        self.label_video.pack(expand=True)

        self.label_status = tk.Label(root, text="Initializing...",
                                      fg="white", bg="black",
                                      font=("fixed", 14))
        self.label_status.pack()

        self.label_info = tk.Label(root, text="", fg="gray", bg="black",
                                    font=("fixed", 10))
        self.label_info.pack()

        tk.Button(root, text="Quit", command=self.on_close).pack(pady=5)
        root.bind("<KeyPress>", lambda e: self.on_close() if e.keysym.lower() == "q" else None)

    def update_video(self, frame):
        """显示一帧画面"""
        if frame is None:
            return
        h, w = frame.shape[:2]
        if w > 720:
            r = 720 / w
            frame = cv2.resize(frame, (720, int(h * r)))
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        imgtk = ImageTk.PhotoImage(Image.fromarray(rgb))
        self.label_video.imgtk = imgtk
        self.label_video.config(image=imgtk)

    def update_status(self, text, is_distracted=False):
        """更新状态: 正常(绿)/分心(红)"""
        self.label_status.config(text=text,
                                  fg="red" if is_distracted else "green")

    def update_info(self, text):
        self.label_info.config(text=text)
