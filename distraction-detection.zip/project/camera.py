"""摄像头: open()打开 → capture()取帧 → close()关闭"""
import cv2
import config


class Camera:
    def __init__(self):
        self.cap = None

    def open(self):
        """打开摄像头（设备号: config.CAMERA_ID）"""
        self.cap = cv2.VideoCapture(config.CAMERA_ID)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.CAMERA_WIDTH)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.CAMERA_HEIGHT)
        if not self.cap.isOpened():
            raise RuntimeError("无法打开摄像头")

    def capture(self):
        """采集一帧，返回 numpy 数组 (H,W,3) BGR"""
        ret, frame = self.cap.read()
        return frame if ret else None

    def close(self):
        """释放摄像头"""
        if self.cap:
            self.cap.release()
