#!/bin/bash
set -e

echo "========================================"
echo " Distraction Detection - 一键安装脚本"
echo "========================================"
echo ""

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo "📦 安装 Python 依赖..."
pip3 install --upgrade pip
pip3 install -r requirements.txt

echo ""
echo "📁 检查必需的目录..."
mkdir -p models captures assets
echo "   ✅ captures/   (截图保存)"
echo "   ✅ models/     (模型文件)"
echo "   ✅ assets/     (提示资源)"

echo ""
echo "⬇️ 检查 YOLOv8 模型..."
if [ ! -f models/yolov8n.pt ]; then
    echo "   下载中..."
    python3 -c "from ultralytics import YOLO; YOLO('yolov8n.pt')" 2>/dev/null
    cp ~/.cache/ultralytics/yolov8n.pt models/ 2>/dev/null || true
    echo "   ✅ yolov8n.pt 已下载"
else
    echo "   ✅ 已存在"
fi

echo ""
echo "🖼️ 检查提示图片..."
if [ ! -f assets/reminder_bg.png ]; then
    echo "   生成默认提示图片..."
    python3 -c "
import cv2, numpy as np
img = np.zeros((400,400,3), dtype=np.uint8)
cv2.putText(img, '⚠ DISTRACTED', (50,180), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,255), 2)
cv2.putText(img, 'Focus on screen!', (80,240), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 1)
cv2.imwrite('assets/reminder_bg.png', img)
"
    echo "   ✅ 已生成"
fi

echo ""
echo "✅ 安装完成！"
echo ""
echo "运行:  cd $PROJECT_DIR && python3 main.py"
echo "退出:  按 Q 或点 Quit 按钮"
echo "========================================"
