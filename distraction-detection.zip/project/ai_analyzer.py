"""AI推理: MediaPipe Face Mesh，只判断最大人脸"""
from dataclasses import dataclass
import mediapipe as mp
import cv2
import time
import config


@dataclass
class AnalyzeResult:
    is_distracted: bool
    label: str
    faces: list = None


class AIAnalyzer:
    def __init__(self):
        self.cooldown_until = 0
        self.last_inference = 0
        self.last_result = AnalyzeResult(False, "init")
        self.distract_start = 0
        self.distract_seconds = 0

        print("Loading MediaPipe Face Mesh (468 landmarks)...")
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            max_num_faces=3,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

    def reset_cooldown(self):
        self.cooldown_until = time.time() + 3

    def analyze(self, frame):
        now = time.time()
        h, w, _ = frame.shape

        if now < self.cooldown_until:
            remain = int(self.cooldown_until - now)
            self.last_result = AnalyzeResult(False, f"cooldown ({remain}s)")
            return self.last_result

        if now - self.last_inference < 0.3:
            return self.last_result

        self.last_inference = now

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_mesh.process(rgb)

        face_list = []
        is_looking_down = False

        if results.multi_face_landmarks:
            # 找出最大的人脸（面积最大的）
            best_face = None
            best_area = 0
            best_landmarks = None

            for face_landmarks in results.multi_face_landmarks:
                xs = [lm.x for lm in face_landmarks.landmark]
                ys = [lm.y for lm in face_landmarks.landmark]
                area = (max(xs) - min(xs)) * (max(ys) - min(ys))
                if area > best_area:
                    best_area = area
                    best_face = face_landmarks

            if best_face:
                landmarks = best_face.landmark
                xs = [lm.x for lm in landmarks]
                ys = [lm.y for lm in landmarks]
                x1 = int(min(xs) * w)
                y1 = int(min(ys) * h)
                x2 = int(max(xs) * w)
                y2 = int(max(ys) * h)
                face_list.append((x1, y1, x2, y2, 1.0))

                forehead = landmarks[10]
                nose = landmarks[1]
                chin = landmarks[152]

                f_to_n = abs(forehead.y - nose.y)
                n_to_c = abs(nose.y - chin.y)

                if f_to_n > n_to_c * 1.5:
                    is_looking_down = True

            # 其他小的人脸也画框但不判断
            for face_landmarks in results.multi_face_landmarks:
                if face_landmarks == best_face:
                    continue
                xs = [lm.x for lm in face_landmarks.landmark]
                ys = [lm.y for lm in face_landmarks.landmark]
                x1 = int(min(xs) * w)
                y1 = int(min(ys) * h)
                x2 = int(max(xs) * w)
                y2 = int(max(ys) * h)
                face_list.append((x1, y1, x2, y2, 0.5))  # 置信度0.5表示其他人

        is_distracted = False
        label = ""

        if len(face_list) == 0:
            if self.distract_start == 0:
                self.distract_start = now
            self.distract_seconds = now - self.distract_start

            if self.distract_seconds >= 5:
                is_distracted = True
                label = f"no face ({int(self.distract_seconds)}s)"
            else:
                label = f"no face -> {5-int(self.distract_seconds)}s"

        elif is_looking_down:
            if self.distract_start == 0:
                self.distract_start = now
            self.distract_seconds = now - self.distract_start

            if self.distract_seconds >= 3:
                is_distracted = True
                label = f"looking down ({int(self.distract_seconds)}s)"
            else:
                label = f"looking down -> {3-int(self.distract_seconds)}s"
        else:
            self.distract_start = 0
            self.distract_seconds = 0
            label = f"face ({len(face_list)})"

        self.last_result = AnalyzeResult(is_distracted, label, face_list)
        return self.last_result
