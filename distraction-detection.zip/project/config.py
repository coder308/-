"""所有配置项，修改参数只需改这里"""
# 摄像头
CAMERA_ID = 0
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480

# 循环间隔（秒）
LOOP_INTERVAL = 0.1

# AI 模型路径（放 models/ 目录下）
MODEL_PATH = "models/yolov8n.pt"

# 提示资源（放 assets/ 目录下）
WARNING_IMAGE_PATH = "assets/reminder_bg.png"
WARNING_SOUND_PATH = "assets/alert.wav"

# 分心画面保存目录
SAVE_DIR = "captures"

# 钉钉群机器人 Webhook（手机提醒）
DINGTALK_WEBHOOK = "https://oapi.dingtalk.com/robot/send?access_token=63d4ecf318d81ed0008609d5ad9c7c5eb16741c3c416b18b34ddaacae05302b8"
