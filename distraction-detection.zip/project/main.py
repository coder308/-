"""主程序: 取画面→AI推理(子线程)→显示+画框"""
import cv2, tkinter as tk, time, config, threading
from camera import Camera
from ai_analyzer import AIAnalyzer
from alert import AlertManager
from ui import MainWindow


class App:
    def __init__(self, root):
        self.cam = Camera()
        self.ai = AIAnalyzer()
        self.alert = AlertManager(ai_analyzer=self.ai, parent=root)
        self.ui = MainWindow(root, on_close_callback=self.on_close)

        self.running = True
        self.fps, self.fc, self.t0 = 0, 0, time.time()
        self.latest_frame = None
        self.latest_result = None
        self.latest_annotated = None
        self.frame_lock = threading.Lock()

        self.cam.open()
        self.ui.update_info("Camera opened")

        self.ai_thread = threading.Thread(target=self.ai_loop, daemon=True)
        self.ai_thread.start()

        self.root.after(10, self.update_ui)

    @property
    def root(self):
        return self.ui.root

    def ai_loop(self):
        while self.running:
            frame = self.cam.capture()
            if frame is None:
                time.sleep(0.1)
                continue

            result = self.ai.analyze(frame)

            annotated = frame.copy()
            if result.faces:
                for face in result.faces:
                    x1, y1, x2, y2, score = face
                    cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 255, 0), 2)

            if result.is_distracted and not self.alert.is_showing():
                print(f"Distracted: {result.label}")
                self.alert.show_warning(frame, result.label)

            with self.frame_lock:
                self.latest_result = result
                self.latest_annotated = annotated
                self.latest_frame = frame

            time.sleep(0.01)

    def update_ui(self):
        if not self.running:
            return

        self.fc += 1
        if time.time() - self.t0 >= 1:
            self.fps, self.fc, self.t0 = self.fc, 0, time.time()

        with self.frame_lock:
            if self.latest_annotated is not None:
                self.ui.update_video(self.latest_annotated)
            elif self.latest_frame is not None:
                self.ui.update_video(self.latest_frame)

            if self.latest_result is not None:
                self.ui.update_status(
                    self.latest_result.label,
                    is_distracted=self.latest_result.is_distracted
                )

        self.ui.update_info(f"FPS:{self.fps}")
        self.root.after(10, self.update_ui)

    def on_close(self):
        self.running = False
        time.sleep(0.2)
        self.cam.close()
        self.alert.cleanup()
        self.root.destroy()


if __name__ == "__main__":
    print("Distraction Detection v1.0 - NVIDIA Jetson")
    root = tk.Tk()
    App(root)
    root.mainloop()
    print("Exited")
